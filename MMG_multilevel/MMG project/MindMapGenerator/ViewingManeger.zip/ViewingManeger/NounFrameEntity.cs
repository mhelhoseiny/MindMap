using System;
using System.Collections.Generic;
using System.Text;
using MindMapGenerator.Drawing_Management;
using mmTMR;
using GoogleImageDrawingEntity;
using System.Drawing;
using SyntacticAnalyzer;
using System.Windows.Forms;
using WordsMatching;
using Google.API.Search;
using ViewingManeger;


namespace MindMapViewingManagement
{
	[Serializable]
    class NounFrameEntity : MM_RectangleWithText
    {
        NounFrame _nounFrame;
        Bitmap _bitmap=null;
        public PictureBox picbox = new PictureBox();
        
        public NounFrameEntity(int x, int y, NounFrame nounFrame)
            :base(0,0,70,40,"","")
        {

            _nounFrame = nounFrame;
            string Text = "";
            
            //if (_nounFrame.Adjective != null)
            //{
            //    foreach (ParseNode adj in _nounFrame.Adjective)
            //        Text += (adj.Text + " ");

            //}

            if (_nounFrame.AdjectivesInfo != null)
            {

                foreach (MyWordInfo mwi in _nounFrame.AdjectivesInfo)
                {
                    Text += (mwi.Word + " ") ;
                   
                }
            }

            Text += (_nounFrame.Text);
            _nounFrame.SearchText1 = Text;
            
           
            //string _wordologyDirectoryPath = Application.ExecutablePath;
            //int index = _wordologyDirectoryPath.LastIndexOf("\\");
            //_wordologyDirectoryPath = _wordologyDirectoryPath.Substring(0, index);

            if (IsGoogleImage())
            {
                ///////////////// habal
                string strpath = "";
                //if (_nounFrame.Text == "agricultural".ToUpper())
                //    strpath = _wordologyDirectoryPath+@"\pics\agricultural.jpg";
                //else if (_nounFrame.Text == "queen".ToUpper())
                //    strpath = _wordologyDirectoryPath+@"\pics\queen.jpg";
                //else if (_nounFrame.Text == "shakespeare".ToUpper())
                //    strpath =_wordologyDirectoryPath+@"\pics\shakespeare.jpg";
                //else if (_nounFrame.Text == "living".ToUpper())
                //    strpath = _wordologyDirectoryPath+@"\pics\coins.jpg";
                //else if (_nounFrame.Text == "writer".ToUpper())
                //    strpath = _wordologyDirectoryPath+@"\pics\writer.jpg";
                
                ////////////////////////////

                if (strpath != "")
                    _bitmap = new Bitmap(strpath);
                else
                {
                    //_bitmap = GoogleSearch.GetImage(_nounFrame.SearchText1);

                    NewGoogleSearch google = new NewGoogleSearch();
                    IList<IImageResult> Results = google.Search2(_nounFrame.SearchText1, 2, ImageSize.small, Colorization.all, ImageType.all, FileType.bmp);
                    // if (Results.Count > 500000 && Results.Count < 15000000)
                    double R;
                    double.TryParse(_nounFrame.SearchText1,out R);
                
                    if(Results.Count>=1&&R==0)
                    {
                        google.LoadImageFromUrl(Results[0].TbImage.Url, picbox);
                        _bitmap = new Bitmap(picbox.Image);
                        _rectangle = new Rectangle(x, y, _bitmap.Width, _bitmap.Height);
                        _position = new PointF(x + _bitmap.Width / 2, y + _bitmap.Height / 2);
                    }
                    
                }
                    /////////////////////////
                //_rectangle = new Rectangle(x, y, _bitmap.Width, _bitmap.Height);
                //_position = new PointF(x + _bitmap.Width / 2, y + _bitmap.Height / 2);
            }
        }

        private bool IsGoogleImage()
        {
            //return false;
            //if (_nounFrame.ParseNode.Children != null)
            //{
            //    ParseNode pn = (ParseNode)_nounFrame.ParseNode.Children[0];
            //    if (pn.Goal != "PRO_N")
            //    {
            //        return true;
            //    }
            //    else
            //    {
            //        if (_nounFrame.Text == "Shakespeare")
            //        {
            //            return true;
            //        }
            //        return false;
            //    }

            //}

            return true;
            //return false;
        }

      
        
        public override void Draw(System.Drawing.Graphics graphics)
        {
            //string Text = "";

            //if (_nounFrame.Adjective != null)
            //{
            //    foreach (ParseNode adj in _nounFrame.Adjective)
            //        Text += (adj.Text + " ");

            //}
            //Text += (_nounFrame.Text);

            if (_bitmap == null)
            {
                PointF point = new Point();
                point.X = this.Position.X - 40;
                point.Y = this.Position.Y + 30;

                base.Draw(graphics);
                //graphics.DrawImage(_bitmap, _rectangle.Location);
                graphics.DrawString(_nounFrame.SearchText1, new Font(FontFamily.GenericSansSerif, 14), new System.Drawing.SolidBrush(Color.Black), point);
                
            }
            else
            {
                int h=_bitmap.Height/2;
                int w=_bitmap.Width/2;
                PointF point = new Point();
                point.X = this.Position.X-w;
                point.Y = this.Position.Y+h;
                graphics.DrawImage(_bitmap, _rectangle.Location);
                graphics.DrawString(_nounFrame.SearchText1, new Font(FontFamily.GenericSansSerif, 14), new System.Drawing.SolidBrush(Color.Black), point);
            }
        }
    }

       
}
