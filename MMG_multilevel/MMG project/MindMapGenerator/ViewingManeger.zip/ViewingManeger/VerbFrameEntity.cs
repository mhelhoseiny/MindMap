using System;
using System.Collections.Generic;
using System.Text;
using MindMapGenerator.Drawing_Management;
using mmTMR;
using GoogleImageDrawingEntity;
using System.Drawing;
using SyntacticAnalyzer;
using WordsMatching;
using Google.API.Search;
using ViewingManeger;
using System.Windows.Forms;

namespace MindMapViewingManagement
{
	[Serializable]
    class VerbFrameEntity : MM_RectangleWithText
    {
        VerbFrame _verbFrame;
        Bitmap _bitmap=null;
        public PictureBox picbox = new PictureBox();

         public VerbFrameEntity(int x, int y, VerbFrame verbFrame)
             : base(0, 0, 70, 40, verbFrame.VerbName,"")
        
        {
            string Text = "";
            _verbFrame = verbFrame;
            if (_verbFrame.AdverbsInfo != null)
            {
                foreach (MyWordInfo mwi in _verbFrame.AdverbsInfo)
                {
                    Text += mwi.Word;

                }
            }
            Text += (_verbFrame.VerbName);

            if (IsGoogleImage())
            {
                //_bitmap = GoogleSearch.GetImage(verbFrame.VerbName);
                //_rectangle = new Rectangle(x, y, _bitmap.Width, _bitmap.Height);
                //_position = new PointF(x + _bitmap.Width / 2, y + _bitmap.Height / 2);
                


                    NewGoogleSearch google = new NewGoogleSearch();
                    IList<IImageResult> Results = google.Search2(_verbFrame.VerbName, 2, ImageSize.small, Colorization.all, ImageType.all, FileType.bmp);
                    if (Results.Count >= 1)
                    {
                        google.LoadImageFromUrl(Results[0].TbImage.Url, picbox);
                        _bitmap = new Bitmap(picbox.Image);
                        _rectangle = new Rectangle(x, y, _bitmap.Width, _bitmap.Height);
                        _position = new PointF(x + _bitmap.Width / 2, y + _bitmap.Height / 2);
                    }
                
            }
            
        }

        private bool IsGoogleImage()
        {
            return false;
        }
        public override void Draw(System.Drawing.Graphics graphics)
        {
            if (_bitmap == null)
            {
                PointF point = new Point();
                point.X = this.Position.X - 40;
                point.Y = this.Position.Y + 30;

                string Text = "";
                //if (_verbFrame.Adverb != null)
                //{
                //    foreach (ParseNode adv in _verbFrame._Adverb)
                //        Text += (adv.Text + " ");
                //}
                //if (_verbFrame.Adverb != null)
                //{
                //    foreach (string adv in _verbFrame._Adverb)
                //        Text += (adv + " ");
                //}

                if (_verbFrame.AdverbsInfo != null)
                {
                    foreach (MyWordInfo mwi in _verbFrame.AdverbsInfo)
                    {
                        Text += (mwi.Word + " ");

                    }
                }
                Text += (_verbFrame.VerbName);

                base.Draw(graphics);
               // graphics.DrawString(Text, new Font(FontFamily.GenericSansSerif, 20), new System.Drawing.SolidBrush(Color.Black), point);
            }
            else
            {
                int h = _bitmap.Height / 2;
                int w = _bitmap.Width / 2;
                PointF point = new Point();
                point.X = this.Position.X - w;
                point.Y = this.Position.Y + h;
                graphics.DrawImage(_bitmap, _rectangle.Location);
                graphics.DrawString(Text, new Font(FontFamily.GenericSansSerif, 14), new System.Drawing.SolidBrush(Color.Black), point);
            }
        }


    }
}
