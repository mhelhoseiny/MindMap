﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Ilan;
using System.Collections;
using System.Text.RegularExpressions;
using System.Net;
using Google.API.Search;
using System.Diagnostics;

namespace ViewingManeger
{
    class NewGoogleSearch
    {
        
        
        public NewGoogleSearch()
        {

        }

        public IList<IImageResult> Search2(string query, int count, ImageSize imagesize, Colorization coloriztion, ImageType imagetype, FileType filetype)
        {
            IList<IImageResult> Results = Google.API.Search.GimageSearcher.Search(query, count, imagesize, coloriztion, imagetype, filetype);
            
            return Results;
        }

        public void LoadImageFromUrl(string url, PictureBox pb)
        {
            HttpWebRequest request = (HttpWebRequest)System.Net.HttpWebRequest.Create(url);
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            
            
            Image img = Image.FromStream(response.GetResponseStream());
            
            response.Close();
            pb.SizeMode = PictureBoxSizeMode.StretchImage;
            pb.Image = img;
        }
    }
}
